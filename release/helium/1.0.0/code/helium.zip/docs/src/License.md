### License

This project is released under codecanyon standard and extended licenses. For more info, please check this link [link](https://codecanyon.net/licenses/standard).