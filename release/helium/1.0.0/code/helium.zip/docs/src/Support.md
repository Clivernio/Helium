### Support

*Please read help files included with my items before anything.*

Support for my items includes:

- Answering technical questions about item’s features.
- Assistance with reported bugs and issues.
- Providing updates to ensure compatibility with new software versions.
- Help with included 3rd party assets.

Support for my items do not include:

- Customization and installation services.

*Please send any support request to this email [support@clivern.com](mailto:support@clivern.com). We’re glad to help!*