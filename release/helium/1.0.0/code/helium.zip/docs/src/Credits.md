### Credits

- [Symfony - PHP Framework.](https://symfony.com/)
- [Tabler - HTML Dashboard UI Kit built on Bootstrap.](https://github.com/tabler/tabler)
- [Vuejs.](https://vuejs.org/)
- [jQuery.](https://jquery.com/)
- [Axios.](https://axios-http.com/)
- [Toastr.](https://codeseven.github.io/toastr/)
- [Ansible.](https://www.ansible.com/)
- [mdBook.](https://github.com/rust-lang/mdBook)
