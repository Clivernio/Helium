### Translation

Please translate the `messages.xlf` included with the release files and send the translated file to [support@clivern.com](mailto:support@clivern.com).

```xml
<?xml version="1.0" encoding="utf-8"?>
<xliff xmlns="urn:oasis:names:tc:xliff:document:1.2" version="1.2">
  <file source-language="en" target-language="fr" datatype="plaintext" original="file.ext">
    <header>
      <tool tool-id="symfony" tool-name="Symfony"/>
    </header>
    <body>
      <trans-unit id="TnDx.SS" resname="Reset Password">
        <source>Reset Password</source>
        <target>réinitialiser le mot de passe</target>
      </trans-unit>
```
