### Versioning

For transparency into our release cycle and in striving to maintain backward compatibility, Helium is maintained under the [Semantic Versioning guidelines](https://semver.org/) and release process is predictable and business-friendly.

See the changelog section for changelogs for each release version of Helium. It contains summaries of the most noteworthy changes made in each release.
