### Free Hosting

You can get at least 3 months of a free hosting to run `Helium`. Please feel free to use one of the following links to register:

* [$200 from Digitalocean.](https://m.do.co/c/7f92efa0b9c1)
* [$250 from Vultr.](https://www.vultr.com/promo/try250/)
* [$300 from Google Cloud.](https://cloud.google.com/free)
* [12 Month free from AWS.](https://aws.amazon.com/free/)
* [$100 from Linode.](https://www.linode.com/lp/affiliate-referral/)
