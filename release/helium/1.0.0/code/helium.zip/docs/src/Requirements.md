### Requirements

- Linux Operating System.
- Apache or Nginx with PHP-FPM
- PHP 7.4+.
- MySQL 5+ or MariaDB.
- Composer.

*We suggest using a `Virtual Server` (VPS) not shared hosting since `Helium` requires a two running background process to send emails on time. You can get a free VPS for at least three months, [Please check free hosting section](Hosting.html)*
