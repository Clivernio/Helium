<?php

declare(strict_types=1);

/*
 * This file is part of the Clivern/Helium project.
 * (c) Clivern <hello@clivern.com>
 */

namespace App\Message;

/**
 * Message Interface.
 */
interface MessageInterface
{
}
